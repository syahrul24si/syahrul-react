export default function PageHeader() {
    return (
        <div
            id="pageheader-container"
            className="flex items-center justify-between p-4"
        >
            <div id="pageheader-left" className="flex flex-col">
                <span
                    id="pageheader-title"
                    className="text-3xl font-semibold"
                >
                    Dashboard
                </span>

                <div
                    id="breadcrumb-links"
                    className="mt-2 flex items-center space-x-2 font-medium"
                >
                    <span id="breadcrumb-home" className="text-gray-500">
                        Dashboard
                    </span>
                    <span id="breadcrumb-separator" className="text-gray-500">
                        /
                    </span>
                    <span id="breadcrumb-current" className="text-gray-500">
                        Order List
                    </span>
                </div>
            </div>

            <div id="action-button">
                <button
                    id="add-button"
                    className="rounded-lg bg-green-500 px-4 py-2 text-white"
                >
                    Add Button
                </button>
            </div>
        </div>
    );
}